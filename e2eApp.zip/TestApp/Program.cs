﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SampleDataLib;

namespace TestApp
{
    class Program
    {
        static IPatientDB db = PatientFactory.GetPatientDB();
        static void Main(string[] args)
        {
            //db.AddPatient(new tblPatient { PatientName = "Phaniraj", AdmitDate = DateTime.Now.AddDays(-23), PatientLocation = "Bangalore" });
            db.AddPatient(new tblPatient { PatientName = "Ramnath", AdmitDate = DateTime.Now.AddDays(-123), PatientLocation = "Bangalore" });
            db.AddPatient(new tblPatient { PatientName = "JoyDip", AdmitDate = DateTime.Now.AddDays(-45), PatientLocation = "Mysore" });
            db.AddPatient(new tblPatient { PatientName = "Sumanth", AdmitDate = DateTime.Now.AddDays(-67), PatientLocation = "Mysore" });
            db.AddPatient(new tblPatient { PatientName = "Aravind", AdmitDate = DateTime.Now.AddDays(-34), PatientLocation = "Bangalore" });
            db.AddPatient(new tblPatient { PatientName = "Ananth", AdmitDate = DateTime.Now.AddDays(-98), PatientLocation = "Hubli" });
            db.AddPatient(new tblPatient { PatientName = "Chandra", AdmitDate = DateTime.Now.AddDays(-13), PatientLocation = "Bangalore" });

        }
    }
}
