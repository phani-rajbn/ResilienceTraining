﻿//gets the date format.
function getDate(dt) {
    let date = new Date(dt);
    let month = date.getMonth();//0-11
    let year = date.getFullYear();
    let day = date.getDay();
    return `${day}/${month + 1}/${year}`;
}


function insertRec() {
    //get the input values:
    let p = {
        "PatientName" : $("#pNewName").val(),
        "PatientLocation" : $("#pNewLoc").val(),
        "AdmitDate" : $("#pNewDate").val()
    };
    $.post(svcUrl, p, () => {
        alert("Patient details added to the data base")
    });
}
let svcUrl = "http://localhost:53995/api";

function updateRec() {
    let p = {
        "PatientID": $("#pId").text(),
        "PatientName": $("#pName").val(),
        "PatientLocation": $("#pLoc").val(),
        "AdmitDate": $("#pDate").val()
    };
    $.ajax({
        type: "PUT",
        url: svcUrl,
        data: p,
        success: () => {
            alert("Updated to the database")
        }
    });
}


function getRecords() {
    $.get(svcUrl, (res) => {
        $.each(res, (index, val) => {
            let row = `<tr><td>${getDate(val.AdmitDate)}</td><td>${val.PatientID}</td><td>${val.PatientName}</td><td>${val.PatientLocation}</td><td><a href='#' info = '${val.PatientID}'/>Edit</td></tr>`;
            $("table").append(row);
            $("a").click(function () {
                let id = $(this).attr("info");
                findRec(id);
                return;
            })
        })
    })
}
function findRec(id) {
    let url = "http://localhost:53995/api/PatientInfo/" + id;
    $.get(url, (res) => {
        $("#pName").val(res.PatientName);
        $("#pLoc").val(res.PatientLocation);
        $("#pDate").val(res.AdmitDate.toString());
        $("#pId").text(res.PatientID);//text is for normal HTML Tags, val is for input tags.
    })
}