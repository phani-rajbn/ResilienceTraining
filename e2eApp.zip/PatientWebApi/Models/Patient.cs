﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PatientWebApi.Models
{
    public class PatientInfo
    {
        public int PatientID { get; set; }
        public string PatientName { get; set; }
        public string PatientLocation { get; set; }
        public DateTime AdmitDate { get; set; }
    }
}