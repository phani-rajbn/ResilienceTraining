﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using PatientWebApi.Models;
using SampleDataLib;

namespace PatientWebApi.Controllers
{
    [EnableCors("*", "*", "*")]
    public class PatientInfoController : ApiController
    {
        public List<PatientInfo> GetAllPatients()
        {
            var component = PatientFactory.GetPatientDB();
            var list = from pt in component.GetAllPatients()//List<tblPatient>
                       select new PatientInfo
                       {
                           AdmitDate = pt.AdmitDate,
                           PatientID = pt.PatientID,
                           PatientLocation = pt.PatientLocation,
                           PatientName = pt.PatientName
                       };
            return list.ToList();
        }

        public PatientInfo GetPatient(string id)
        {
            var pId = int.Parse(id);
            var com = PatientFactory.GetPatientDB();
            var selected = from pt in com.GetAllPatients() //LINQ always returns a collection even if it is a single rec, it's a collection of size 1
                           where pt.PatientID == pId
                           select new PatientInfo
                           {
                               AdmitDate = pt.AdmitDate,
                               PatientID = pt.PatientID,
                               PatientLocation = pt.PatientLocation,
                               PatientName = pt.PatientName
                           };
            return selected.FirstOrDefault();
        }

        [HttpPost]
        public void AddPatient(PatientInfo info)
        {
            var newRow = new tblPatient
            {
                AdmitDate = info.AdmitDate,
                PatientID = info.PatientID,
                PatientLocation = info.PatientLocation,
                PatientName = info.PatientName
            };
            var compoent = PatientFactory.GetPatientDB();
            compoent.AddPatient(newRow);
        }

        [HttpPut]
        public void UpdateRecord(PatientInfo info)
        {
            var newRow = new tblPatient
            {
                AdmitDate = info.AdmitDate,
                PatientID = info.PatientID,
                PatientLocation = info.PatientLocation,
                PatientName = info.PatientName
            };
            var compoent = PatientFactory.GetPatientDB();
            compoent.UpdatePatient(newRow);
        }
    }
}