﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleDataLib
{
    /// <summary>
    /// Exception Class created to raise when there is an issue with the Data access of PatientDB
    /// </summary>
    public class PatientDBException : ApplicationException
    {
        public PatientDBException() { }
        public PatientDBException(string message) : base(message) { }
        public PatientDBException(string message, Exception inner) : base(message, inner) { }
    }

    public interface IPatientDB
    {
        void AddPatient(tblPatient p);
        void UpdatePatient(tblPatient p);

        /// <summary>
        /// Deletes the Patient info from the database based on ID
        /// <paramref name="id">
        /// ID of the Patient to delete
        /// </paramref>
        /// <exception>SampleDataLib.PatientDBException</exception>
        /// </summary>
        /// <param name="id"></param>
        void DeletePatient(int id);
        List<tblPatient> GetAllPatients();
    }

    class PatientDB : IPatientDB
    {
        public void AddPatient(tblPatient p)
        {
            var context = new CSharpProjectEntities();
            context.tblPatients.Add(p);//adds the record...
            context.SaveChanges();//Commits UR changes to the database
        }

        public void DeletePatient(int id)
        {
            var context = new CSharpProjectEntities();
            var foundRec = context.tblPatients.FirstOrDefault((p) => p.PatientID == id);
            if (foundRec == null)
            {
                throw new PatientDBException($"Patient by ID {id} not found to delete");
            }
            context.tblPatients.Remove(foundRec);//Remove the record...
            context.SaveChanges();
        }

        public List<tblPatient> GetAllPatients()
        {
            var context = new CSharpProjectEntities();
            return context.tblPatients.ToList();
        }

        public void UpdatePatient(tblPatient p)
        {
            var context = new CSharpProjectEntities();
            var foundRec = context.tblPatients.FirstOrDefault((pt) => pt.PatientID == p.PatientID);
            if (foundRec == null)
            {
                throw new PatientDBException($"Patient by ID {p.PatientID} not found to Update");
            }
            foundRec.PatientName = p.PatientName;
            foundRec.PatientLocation = p.PatientLocation;
            foundRec.AdmitDate = p.AdmitDate;
            foundRec.PatientID = p.PatientID;
            context.SaveChanges();
        }
    }

    /// <summary>
    /// Factory Component that returns a valid Patient DB Implementor Object
    /// </summary>
    public static class PatientFactory
    {
        /// <summary>
        /// Gets the Valid Patient Implementor object. Use this to get the interface Object of IPatientDB
        /// </summary>
        /// <returns>An object of IPatientDB implementor</returns>
        public static IPatientDB GetPatientDB()
        {
            return new PatientDB();
        }
    }
}
